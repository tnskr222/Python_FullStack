# python script to swap data of two variables
x = input("Enter Name ")
y = input("Enter Place ")
x,y = y,x
print(f"x = {x}", f"y = {y}", sep='\n')