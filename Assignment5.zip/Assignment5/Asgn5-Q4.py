# python script to find x power y, where values of x and y are given by user

x = int(input("Enter x Value "))
y = int(input("Enter y value "))
z = x**y
print(f'{x} power {y} = {z}')