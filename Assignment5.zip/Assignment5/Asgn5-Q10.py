# python script to use IS operator to display if both variables are the same object or not?
a = "hello, prime, iNeuron"
b = "iNeuron"
if b is a:
    print(f"b and a are same")
else:
    print(f"b and a are not same")