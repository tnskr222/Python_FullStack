# python script to use IN operator to display the data present in the list
a = "hello, prime, iNeuron"
b = "iNeuron"
if b in a:
    print(f"{b} is in a")
else:
    print(f"{b} is not in a")
