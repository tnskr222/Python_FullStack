# python script to check whether a given number is even or odd

x =int(input("Enter a number "))
if x%2==0:
    print(f"{x} is even")
else:
    print(f"{x} is odd")