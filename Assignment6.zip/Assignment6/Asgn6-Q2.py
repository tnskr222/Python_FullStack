# python script to check whether a given number is divisible by 5 or not

x= int(input("Enter a number "))

if x%5==0:
    print(f"{x} is divisible by 5")
else:
    print(f"{x} is not divisible by 5")