# python script to check whether a given number is positive or non-positive

x = int(input("Enter a number : "))
if x>0:
    print(f"{x} is positive")
else:
    print(f"{x} is non-positive")