# value of variable is assigned in this file and then imported to A0 file
x=5
y="MySirG"