# Values from A1.py file is import here and then printed
x=10
y=16
from A1 import x as B
from A1 import y as c
print(B,c, sep='\n')