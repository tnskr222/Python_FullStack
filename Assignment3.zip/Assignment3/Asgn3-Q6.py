# python script to print any number and its hexadecimal equivalent

x = int(input("enter a number : "))
y = hex(x)
print('hexadecimal equivalent of', x, 'is :', y) 