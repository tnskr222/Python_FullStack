# python script to store binary number 1100101 in a variable and print it in decimal format

x = 0b1100101
print('decimal equivalent of binary number', bin(x).replace('0b',''), 'is :', x) 