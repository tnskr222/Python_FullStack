# python script to add two numbers 25 (in octal) and 39 (in hexadecimal) and display the result in binary format

a=0o25
b=0x39
print('Addition of 25 (in octal) and 39 (in hexadecimal) gives result in binary format as', bin(a+b).replace('0b',''))
