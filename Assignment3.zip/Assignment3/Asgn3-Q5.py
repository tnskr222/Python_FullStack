# python script to print any number and its octal equivalent

x = int(input("enter a number : "))
y = oct(x)
print('Octal equivalent of', x, 'is :', y) 