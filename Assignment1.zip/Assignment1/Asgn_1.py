x=6
y=7
z=x+y
z=z+5
print(z)