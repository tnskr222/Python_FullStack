# python script to calculate the square of a number. Number is entered by the user.

x = int(input('Enter a number '))
y = x**2
print('Square of a number is : ', y)