# python script to calculate the area of Triangle. Number is entered by the user.

b = float(input("Enter the base of  triangle"))
h = float(input("Enter the height of  triangle"))
c =b*h*0.5
print('Area of Triangle is : ',c)