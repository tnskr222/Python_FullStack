# python script which takes the radius from the user and display area of a circle
import math

a = float(input('Enter radius of circle : '))
b = math.pi*a**2
print('area of Circle is :',b)