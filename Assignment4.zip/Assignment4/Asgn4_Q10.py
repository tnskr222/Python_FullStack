# python script to calculate area of a rectangle

l = float(input('Enter length of Rectangle '))
b = float(input('Enter breadth of Rectangle '))
A = l*b
print('Area of Rectangle is ',A)