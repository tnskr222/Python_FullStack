# python script to calculate simple interest

P = int(input('Enter Principal Amount'))
T = float(input("Enter Time in Years"))
R = float(input('Enter Interest Rate'))
I = P*T*R/100
print(I)