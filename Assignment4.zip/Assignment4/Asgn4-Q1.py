# python script to take your name as input from the user and then print it
Name = input("Enter your Name")
print(Name)