# python script to calculate the volume of a cuboid

l = float(input('Enter length of Cuboid '))
b = float(input('Enter breadth of Cuboid '))
h = float(input('Enter height of Cuboid '))
v =l*b*h
print('Volume of cuboid is ', v)