# python script which takes two numbers from the user, then calculate their sum and display the result

a =int(input("Enter First Number :"))
b =int(input("Enter Second Number :"))
c = a+b
print('result is :',c)