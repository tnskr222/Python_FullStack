# python script to take input from the user. Input must be a number.

a = int(input("Enter number "))