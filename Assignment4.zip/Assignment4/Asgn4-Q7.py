#  python script to calculate average of three numbers, entered by the user

a = int(input('Enter First Number '))
b = int(input('Enter Second Number '))
c = int(input('Enter Third Number '))
d = (a+b+c)/3
print(d)